### ChangeDataRangeModification

**Category:** Charts — requires `xmlns:ueabc`

Requires additional namespace:
```xml
xmlns:ueabc="clr-namespace:UiPath.Excel.Activities.Business.ChartModifications;assembly=UiPath.Excel.Activities"
```

| Key Attributes |
|---------------|
| `Range` (nested inside `UpdateChartX` body) |

Use `uip rpa get-default-activity-xaml --use-studio` for full XAML.
